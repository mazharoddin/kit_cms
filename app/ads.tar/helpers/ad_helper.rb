module AdHelper
end
