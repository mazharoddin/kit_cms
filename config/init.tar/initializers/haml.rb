module Haml
  Haml::Template.options[:attr_wrapper] = '"'
end

