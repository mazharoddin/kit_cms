  class QueryMethods 
  end

